import java.util.ArrayList;

/**
 * Player class that defines the Player object
 * Contains basic functions to get and store a Player's data
 * and initialize it. 
 */
public class Player {
    
    String name;
    ArrayList<String> sports;

    /**
     * Player constructor
     * 
     * Assigns a string to the player's name
     * Initializes the arraylist of sports to an empty list
     * @param name string containing player's name
     */
    public Player(String name) {
        this.name = name;
        sports =  new ArrayList<>();
    } 

    public void addSport(String sport)
    {
        sports.add(sport);
    }

    public String getName() {
        return name;
    }

    public ArrayList<String> getSports() {
        return sports;
    }

    @Override
    public String toString() {
        return "\n" + name + ": " + sports.toString();
    }    


    
}

import java.util.ArrayList;

/**
 * Sport class that defines the Sport object
 * Contains basic functions to get and store a Sport's
 * data and initialize it. 
 */
public class Sport {

    String sportName;

    ArrayList<String> playerList;

    /**
     * Sport constructor
     * 
     * Assigns a string to the sport's name
     * Initializes the arraylist of players to an empty list
     * @param name string containing player's name
     */
    public Sport(String sportName) {
        super();
        playerList = new ArrayList<>();
        this.sportName = sportName;
    }

    public void addPlayerName(String name)
    {
        playerList.add(name);
    }

    @Override
    public String toString() {
        return  playerList.toString() ;
    }
        
}

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author Emanuel Dobra
 * 
 * App class that manipulates Player and Sport objects after reading from data files.
 */
public class App {
    static ArrayList<Player> playerList = new ArrayList<>();
    static HashMap<String, Sport> sportMap = new HashMap<>();

    /**
     * Players and sports application
     * <br>
     * This application reads information consisting of player names and the sports they play 
     * from an input file.   
     * Each line of the input file must consist of a player name followed by a comma-separated 
     * list of sports.  A new player object is created from the data contained in each line of the file.
     * Each new player object is added to an ArrayList of Player objects
     * <br>
     * 
     * @param args - args[0] will hold name of input file (to be done in lab)
     */
    public static void main(String[] args)  {
        //System.out.println(args[0]);
        loadPlayerFile("res/" + args[0]);
        initSportMap();
        System.out.println(playerList);
        System.out.println(sportMap);
    }
    
    /**
     * initSportMap
     * 
     * 1 - Loop through the player list
     * 2 -- Create an arraylist of that player's sports
     * 3 -- Loop through the arraylist of sports 
     * 4 --- Check if sport is unique
     * 5 ---- If so, create a new sport object with that name
     * 6 ---- Then associate entry to the sport hashmap
     * 7 --- Add player to that sport entry 
     */
    private static void initSportMap() {
        for (Player player : playerList) {
            ArrayList<String> playerSportsList = player.getSports();
            for (String sportName : playerSportsList) {
                if (sportMap.get(sportName) == null) {
                    Sport sport = new Sport(sportName);
                    sportMap.put(sportName, sport);
                }
                sportMap.get(sportName).addPlayerName(player.getName());
            }
        }
    }

    /**
     * loadPlayerFile
     * 
     * 1 - Open input and output files
     * 2 - For each line of input
     * 3 -- split line into tokans
     * 4 -- create new player whose name is given by token[0]
     * 5 -- add remaining tokens to player's list of sports 
     * 6 - add player to player list
     */

    private static void loadPlayerFile(String fileName) {
        File file = new File(fileName);
        try{
            // 1            
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // 2
            String line = bufferedReader.readLine();
            while (line != null)
            {
                String[] tokens = line.split(",");              // 3
                Player player = new Player(tokens[0].trim());   // 4
                for (int i = 1; i < tokens.length; i++) {       // 5
                    String sport = tokens[i].trim();
                    player.addSport(sport);
                }                
                playerList.add(player);                         // 6

                line = bufferedReader.readLine();               
            }
            bufferedReader.close();
        }
        catch(NullPointerException e)
        {
            System.err.println("loadPlayerFile");
            System.err.println(e.getMessage());
        }
        catch (FileNotFoundException e)
        {
            System.err.println("Check the input file name");
            e.printStackTrace();
        }
        catch (IOException e)
        {
            System.out.println("Problem reading data from input file");
            e.printStackTrace();
        }
    }
}
